from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, login_required, logout_user, current_user
from app import app, db, login_manager
from models import User, Candidate, Vote
from database import add_user, get_user_by_username, get_all_candidates, get_candidate_by_id, record_vote, get_vote_counts, get_total_voters, get_total_votes
from werkzeug.security import generate_password_hash, check_password_hash
import uuid

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Rest of your route definitions remain the same
# ...

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = get_user_by_username(username)

        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('voting_page'))
        else:
            flash('Invalid username or password')

    return render_template('voter_login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        date_of_birth = request.form['dateOfBirth']
        phone_number = request.form['phoneNumber']
        voter_id = request.form['voterId']

        if get_user_by_username(username):
            flash('Username already exists')
            return redirect(url_for('register'))

        add_user(username, password, first_name, last_name, date_of_birth, phone_number, voter_id)
        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))

return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/voting')
@login_required
def voting_page():
    if current_user.has_voted:
        flash('You have already voted.')
        return redirect(url_for('index'))
    candidates = get_all_candidates()
    return render_template('voting_page.html', candidates=candidates)

@app.route('/candidate/<int:id>')
@login_required
def candidate_details(id):
    candidate = get_candidate_by_id(id)
    return render_template('candidate_details.html', candidate=candidate)

@app.route('/vote', methods=['POST'])
@login_required
def submit_vote():
    if current_user.has_voted:
        flash('You have already voted.')
        return redirect(url_for('index'))

    candidate_id = request.form['candidate_id']
    record_vote(current_user.id, candidate_id)
    current_user.has_voted = True
    db.session.commit()

    vote_reference = str(uuid.uuid4())
    return render_template('vote_confirmation.html', vote_reference=vote_reference)

@app.route('/admin')
@login_required
def admin_dashboard():
    if current_user.username != 'admin896':
        flash('You do not have permission to access this page.')
        return redirect(url_for('index'))

    vote_counts = get_vote_counts()
    total_voters = get_total_voters()
    votes_cast = get_total_votes()
    voting_percentage = (votes_cast / total_voters) * 100 if total_voters > 0 else 0

    return render_template('admin_dashboard.html', 
                           vote_counts=vote_counts, 
                           total_voters=total_voters, 
                           votes_cast=votes_cast, 
                           voting_percentage=voting_percentage)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin896' and password == '25B79#!?':
            user = User(username='admin896')
            login_user(user)
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid admin credentials')
    return render_template('admin_login.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin896' and password == '25B79#!?':
            user = User(username='admin896')
            login_user(user)
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid admin credentials')
    return render_template('admin_login.html')