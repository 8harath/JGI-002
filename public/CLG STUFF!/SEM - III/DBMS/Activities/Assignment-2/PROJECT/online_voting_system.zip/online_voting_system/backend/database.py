from app import db
from models import User, Candidate, Vote

def init_db():
    db.create_all()

def add_user(username, password, first_name, last_name, date_of_birth, phone_number, voter_id):
    user = User(username=username, first_name=first_name, last_name=last_name,
                date_of_birth=date_of_birth, phone_number=phone_number, voter_id=voter_id)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

def get_user_by_username(username):
    return User.query.filter_by(username=username).first()

def add_candidate(name, party, photo_url, promises, background):
    candidate = Candidate(name=name, party=party, photo_url=photo_url, promises=promises, background=background)
    db.session.add(candidate)
    db.session.commit()

def get_all_candidates():
    return Candidate.query.all()

def get_candidate_by_id(candidate_id):
    return Candidate.query.get(candidate_id)

def record_vote(user_id, candidate_id):
    vote = Vote(user_id=user_id, candidate_id=candidate_id)
    db.session.add(vote)
    db.session.commit()

def get_vote_counts():
    return db.session.query(Candidate.name, Candidate.party, db.func.count(Vote.id)).join(Vote).group_by(Candidate.id).all()

def get_total_voters():
    return User.query.count()

def get_total_votes():
    return Vote.query.count()