from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'  # Change this to a random secret key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///voting_system.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Load user function after the app is created to avoid circular import
@login_manager.user_loader
def load_user(user_id):
    from models import User  # Import User model here to avoid circular import
    return User.query.get(int(user_id))

if __name__ == '__main__':
    app.run(debug=True)
